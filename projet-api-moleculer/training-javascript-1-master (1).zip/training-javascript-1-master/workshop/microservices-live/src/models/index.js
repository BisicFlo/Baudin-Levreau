const TodoModel = require("./TodoModel");

module.exports = {
	Todo: TodoModel,
};
